import logging
class _Logger:
    def __init__(self):
        self._log = logging.getLogger('mobi')
    def debug(self, msg, *args, **kwargs): pass
    def info(self, msg, *args, **kwargs): pass
    def warning(self, msg, *args, **kwargs): pass
    def error(self, msg, *args, **kwargs): pass
    def critical(self, msg, *args, **kwargs): pass
    def exception(self, msg, *args, **kwargs): pass
    def remove(self, *args, **kwargs): pass
    def add(self, *args, **kwargs): return 0
    def level(self, *args, **kwargs): pass
    def opt(self, *args, **kwargs): return self
    def bind(self, *args, **kwargs): return self
logger = _Logger()
